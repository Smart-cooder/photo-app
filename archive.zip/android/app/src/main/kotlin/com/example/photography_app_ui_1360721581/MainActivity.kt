package com.example.photography_app_ui_1360721581

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
